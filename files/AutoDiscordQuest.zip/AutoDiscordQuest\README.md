# Lương Kun - AutoDiscordQuest

Token-only. Give it a Discord user token and it drives quests to completion by
calling the same API endpoints the official client calls. No game, no fake
process, no gateway presence, no Discord client needed.

## Standalone exe

`dist/AutoDiscordQuest.exe` is a single self-contained file. No Python, no install —
copy it anywhere on a Windows 10/11 machine and run it.

```
AutoDiscordQuest.exe                 opens the app
AutoDiscordQuest.exe list            CLI, output reattached to the calling terminal
AutoDiscordQuest.exe token
AutoDiscordQuest.exe --selftest      opens the real UI and drives it, exit 0/1
```

The build is windowed, so double-clicking gives the window with no console box.
When launched from a terminal with CLI arguments it calls `AttachConsole(-1)` and
reconnects stdout/stderr, so the same exe is both the app and the CLI.

**One runtime dependency:** the Microsoft Edge **WebView2 runtime**, which every
supported Windows 10/11 install has because Edge ships it. If it is somehow
missing, the app says so in a dialog naming the fix instead of failing to open.

### Rebuilding

```bat
build_exe.bat
```

or

```bash
pyinstaller --noconfirm --clean quest_sim.spec
```

Build dependencies are in [requirements-build.txt](requirements-build.txt):
PyInstaller plus pywebview — anything missing from the build interpreter is
missing from the exe. `build_exe.bat` checks for `webview` before it starts,
precisely so a build cannot silently ship without a way to open a window. The
env lives in `.venv-build/` here, which is gitignored and safe to delete. Output
lands in `dist/AutoDiscordQuest.exe`, about 20 MB.

## The app

A monochrome window, black and white throughout: a header strip carrying the
live status, then cards for account / actions / quests / console. Two columns at
roughly half and half, quests a touch wider — quests on the left as a card list, console filling the right column for
its full height. Every quest card shows the game's artwork, its own progress bar, `done/target`,
percent, measured rate and ETA, a status badge, and (in a multi-account run)
which account it belongs to. The log tints each line by kind (grey routine,
amber warning, red error, green success).

There is no widget toolkit. Python hosts a WebView2 window with `pywebview` and
the interface is plain HTML/CSS/JS in [ui/](ui) — so the look is not limited by
what a toolkit can draw, and the layout can be worked on in a browser.

```bash
py -3 -m venv .venv-webview
./.venv-webview/Scripts/python.exe -m pip install -r requirements-build.txt
./.venv-webview/Scripts/python.exe quest_web.py            # run it
./.venv-webview/Scripts/python.exe quest_web.py --selftest # drive the UI, then exit
```

`start.bat` runs the same entry point the exe uses.

### Design system

One palette, one motion scale and one depth scale, all custom properties at the
top of [ui/app.css](ui/app.css): a colour or a duration is changed once, and
nothing below invents its own value. Surfaces are translucent layers over a slow
ambient gradient (`drift`, 44s), so depth comes from light rather than from more
shades of grey, and the header and cards are frosted with `backdrop-filter`.
Every quest carries a status rail down its left edge keyed off `data-status`, so
running, finished and failed read at a glance while scrolling.

Motion is a rule here, not a garnish: only `transform`, `opacity`, `filter` and
`box-shadow` are animated, never layout, so the window stays smooth while quests
tick. The first list paint staggers rows in (`riseIn`, 32ms apart) and every
later refresh is deliberately static — re-running a stagger every few seconds
reads as a twitch, not as motion. A running bar carries a moving sheen, the live
dot breathes, log lines slide in, buttons lift on hover and press on click, and
a slow comet of light circles the window edge, snow or rain falls over the
main panel, and the cursor trails sparkles while clicks bloom rings. The Settings modal holds an Animations switch for just those two —
rim and sky canvas — plus a Weather switch flipping the canvas between
snowfall and rain. Everything else keeps moving.
No OS effect flag is wired to this front-end: neither the reduced-motion flag
("Animation effects") nor the reduced-transparency one ("Transparency") can
change how the app looks or moves, so nothing under [ui/](ui) asks a `prefers-*`
media query and the selftest fails the build if one appears. The in-app
Animations switch is the only control over the effects.

**Glass theme.** Settings holds a Default ⇄ Glass switch. Glass is a
per-pixel-transparent window over the live desktop: the DWM system backdrop
(acrylic) frosts the desktop behind it on Windows 11 22H2+, the accent blur
does it on Windows 10, and the page paints near-clear tinted panes with a
stronger `backdrop-filter` diffusion pass plus a specular edge — so the frosted
desktop reads through as liquid glass while solid controls stay opaque and
readable on any wallpaper. Turning it off restores the stock backdrop
explicitly, so no blur leaks into the default theme.

The window behind the page has a colour of its own, and it used to be the wrong
one. Until WebView2 has painted its first frame — while the app starts, and
again each time the window is restored from the taskbar or the zoom button
resizes it — nothing covers the window's own backing, and the stock WinForms
value for that is `SystemColors.Control`, a light `#F0F0F0` — a white screen,
which is what "flashing white / losing the window" was. The backing is painted in the sheet's near-black
instead, so a frame the page has not covered yet reads as the dark repaint it
is; the selftest asserts the live window took the colour.

Spacing is on an 8px grid. `body.plain` strips every effect for a like-for-like
comparison, and `?demo=1` swaps the bridge for a fake one with the same shape, so
the layout can be inspected in a plain browser with no host running — it never
activates on its own.

The one piece of imagery is the tray icon, drawn with Pillow rather than taken
from a font: emoji coverage varies enough across the Segoe faces this app can
land on that a missing glyph shows as a box.

### Account block

Selecting a profile paints the identity in place: the avatar fetched from
Discord's CDN on a worker thread, the display name with tag, the user id in
monospace, and a Nitro pill when `premium_type` says so. A slow CDN never
freezes the window, and an avatar that arrives after you have already switched
accounts is dropped rather than overwriting the new one.

### Desktop action bar

The client selector and *Switch client* sit in their own inset surface with a
hairline border, because that row acts on the machine rather than on the account
and should not read as another account field. **Switch client** is the whole
operation: it saves the session that is on screen first and restarts the client
afterwards, so there is no separate *Save session* button and no *Auto-restart*
to tick.
The far end of the bar carries a live pill — green *Discord running* or grey
*Discord closed* — polled off the UI thread every two seconds.

### Empty state

An account with nothing to do is the common case, not an error, so it gets a
drawn trophy, a line saying so, and a *Refresh quests* button rather than a
blank rectangle. When quests exist but are unaccepted in Discord, the wording
changes to say that instead of claiming everything is done.

### Minimise to tray

The header carries a button that parks the window in the system tray so it can
keep running quests without sitting on top of whatever you are doing. The tray
menu brings the window back or quits it for real.

What it does on its own:

- **auto-scans every Discord profile for a live token** on launch (and on the
  *Rescan profiles* button). It walks each client's leveldb, decrypts the stored
  values, and verifies every candidate against `/users/@me`. Forks are found by
  profile name *or* by content, so an unknown fork still works while an unrelated
  Electron app (an editor, a chat app) is skipped instead of being mined.
- **multi-account:** every account found is listed in the account picker menu as
  name and `@handle` (two rows, then a show-all tail opening the full modal
  with avatars). Switching accounts restarts the worker set, so you are never
  running quests for the wrong account. A pasted token can be used too.
- **saved tokens, instant account switching.** Every token the app ever validates
  is written to `%APPDATA%\quest_sim\accounts.json`, keyed by Discord user id. On
  launch the saved list is merged with the live scan and each remembered token is
  re-checked against `/users/@me`; expired ones are dropped, the rest are offered
  in the dropdown. Logging out of an account in Discord therefore does **not**
  remove it from the app — no re-login, no retyping a token, just pick the name.
  That file holds live account credentials in cleartext; it inherits `%APPDATA%`'s
  ACL. Delete it to wipe the store.
- **a rejected account is explained, not silently dropped.** Every candidate the
  scan finds is checked against `/users/@me`, and the ones that fail are logged
  with the reason instead of just missing from the dropdown. Discord rejecting
  the token (`HTTP 401` — the account was logged out, the password changed, or
  the session was revoked) reads differently from Discord being briefly
  unreachable, because only one of those means the account is really gone.
- **a stale token is dropped silently, not reported as a missing account.** A profile
  keeps every token an account has *ever* used, so after a re-login the old
  revoked one is still on disk beside the new working one. Candidates are
  grouped by the user id encoded in the token and the first live one wins; the
  rest are skipped without a line each. Saved tokens are re-checked on
  every scan and deleted from `accounts.json` the moment they stop working,
  even when the account itself is still perfectly fine.
- **the account on screen becomes the active one.** After every scan the app
  reads which session the desktop client currently shows and selects that
  account, instead of whichever token the scan happened to list first.
- when the quest list is empty it says *why*: nothing enrolled, everything done,
  quests available but not accepted, or **quest access suspended** — that last
  one is Discord's automation enforcement and would otherwise look identical to
  an empty list.
- lists every active uncompleted quest with **all of them pre-selected**, so one
  click on *Run selected* starts them.
- **Run all accounts** — one button, every saved account, in parallel. Quests from
  all accounts are fetched up front and **every quest becomes a card tagged with
  its account**, so all accounts move together on one list. Each account gets its
  own thread running the token engine; log lines are prefixed (`[TheLuong02] ...`).
  *Stop all* unwinds every account at once.
- runs **each quest in its own worker thread**, concurrently — a video quest and
  a play quest can both be in flight at once.
- **video quests run at 7x, fixed.** 7 quest-seconds are credited per real
  second, so a 44s watch finishes in about 7s. There is no speed control; the
  multiplier is a constant (`VIDEO_SPEED` in [quest_sim.py](quest_sim.py)).
- **progress lives on the quest card** — there is no separate progress panel. Each
  card carries its own progress bar, `done/target`, percent and a status badge
  (`queued` / `running` / `complete` / `done` / `error` / `stopped` / `no engine`).
  Running cards also show measured rate and ETA, recomputed twice a second on
  their own timer, independently of how often a worker talks to Discord. The rate
  is *measured* (`seconds gained / seconds elapsed`), not assumed: a 7x video loop
  reports ~7.0x and a play quest that ticks server-side on real elapsed time
  reports ~1.0x. Under three seconds there is not enough signal, so it falls back
  to the fixed per-task rate and the selftest checks both branches.
- **console controls** — *CONSOLE / LOGS* fills the whole right column. The header
  carries *Clear Logs* and an *Auto-scroll* toggle; with auto-scroll off the view
  holds its position while new lines still arrive.
- *Stop all* signals every runner. Closing does the same — **except while a
  desktop switch is running**, when the close is held and happens by itself the
  moment the switch lands. That switch is midway through rewriting the installed
  client's profile directory, and closing on top of it is how Discord is left
  unusable.
- row click toggles selection; unsupported quest types are shown but not
  pre-selected. Activity quests need a stream key in the form
  `call:<channel_id>:1`.

### Verifying it

`AutoDiscordQuest.exe --selftest` does not just check imports. It opens the real
window, stubs the network layer, drives the actual bridge
(`refresh` → `run_selected` → `select_all` → `run_all_accounts` → `stop_all`) and
reads the DOM back: **107 checks**, including that the page raised no JS errors.
It exits non-zero on any failure, so it works as a build gate on the machine the
exe will actually run on. The same suite runs from source with
`python quest_web.py --selftest`.

**What is wired.** Account scan and switching, the token box, the account card,
Refresh with auto-accept, per-quest cards with progress bars and status badges,
row-click select, *Run selected*, *Run all accounts*, *Stop all*, the desktop
client switch, the stream-key row (hidden until an activity quest is listed),
the console with its tag colours and edge-triggered auto-scroll,
minimise/zoom/close, window drag, a settings modal (start with Windows,
animations, weather, completion notice, theme), a donate modal for the author,
a completion ting, and loading skeletons. The event pump sends state Python→JS as batched JSON, 64 events per 50 ms tick.

### Rows are keyed `uid|quest_id`

A row is addressed by account *and* quest, never by quest id alone. The same
quest is live on every account, so a quest-id key makes two accounts' copies of
it collide onto one card and the second account's progress silently overwrites
the first's. The selftest asserts it directly: both stub accounts are served a
quest with the id `a`, and the run has to produce **two** rows (`…100|a` and
`…990|a`) with distinct account chips rather than one.

### Multi-account

*Run all accounts* fetches every account's quests up front, rebuilds one list
with the account name chipped onto each row, then fans out to one thread per
quest: video quests first across all accounts (they finish in seconds), at
most ten quests at the same time in total and five per account. `run_api_engine` cannot drive `PLAY_ACTIVITY` (it only
knows the video and play heartbeats), so activity quests are pulled out and given
their own thread per row — otherwise a multi-account run would be quietly worse
at activities than a single-account one. One account whose quests fail to fetch
is logged and skipped; it does not cost the other accounts their run.


## Switching the Discord desktop client

The *Account* card has a second, separate action — the **Desktop** row — that
does something the token engine never does. The token box feeds the REST API in
the background and is invisible to Discord. The Desktop row rewrites the login
session of the **installed Discord app**, so the window you actually chat and
voice in comes up as a different account. No logout, no email/password, no OTP.

Press **Switch client** and the tool:

1. works out which Discord build to target from the *Desktop* dropdown — only
   builds actually installed are listed (Stable / PTB / Canary / Development),
   and processes are matched by **install path**, not by image name, so
   switching Stable never kills a Canary running beside it;
2. saves the session that is on screen right now under its own user id, so
   switching back later needs no manual login either;
3. closes Discord (`taskkill /F /T`) and waits for the leveldb handles to be
   released, retrying if the updater respawns it;
4. installs the target account's session and starts Discord again
   (`Update.exe --processStart Discord.exe`);
5. logs every step into the console.

**How the session is swapped.** Discord's session lives in the Electron
user-data-dir `%APPDATA%\<flavour>`. The tool keeps one copy of that directory
per account under `%APPDATA%\quest_sim\discord_profiles\<user id>` and switching
copies the wanted copy over the live one. Cache directories (`Cache`, `Code
Cache`, `GPUCache`, `blob_storage`, crash dumps…) are skipped, so a switch moves
a few MB rather than a few hundred. The directory that is live is always saved
*before* it is replaced, so the swap is reversible by construction.

**First switch to an account that was never opened on this desktop.** There is
no saved copy to restore, so the session is written straight into the client's
own storage instead — see *Writing a session with no native library* below. No
manual sign-in is needed, and the write also snapshots the result, so every
later switch to that account is the plain file copy.

**Saving a session is automatic.** Every switch saves the session that is on
screen under its own user id before it replaces it (step 1 above), so there is
no separate *Save session* press and no *Auto-restart* tick — both are steps of
the switch itself. The copy skips the cache directories, so it moves a few MB
rather than a few hundred.

**Writing a session with no native library.** The client keeps its live session
in one Local Storage key, as `dQw4w9WgXcQ:` followed by the base64 of a `v10`
AES-256-GCM blob under the key in `Local State` — the same shape the client
writes for itself. Putting that in place means *writing leveldb*, which used to
mean `plyvel`, which has no Windows wheel and does not compile here.

It does not need to. leveldb is log-structured: a write is an append to its
write-ahead log, and a replayed log outranks any older table file, so an
appended record *is* the write. `leveldb_write.py` does exactly that in the
standard library — CRC32C in leveldb's masked form, the 32 KiB block framing
(including records split FIRST/MIDDLE/LAST across a boundary), the WriteBatch
encoding, and a sequence number read out of the `MANIFEST` rather than guessed,
since a batch that lands below an existing sequence is silently ignored.

Two details that are only visible against a live client, both of which were
found the hard way:

- the value is a **JSON string** — `"dQw4w9WgXcQ:…"`, quotes included. A bare
  value does not parse, the client drops it, and it starts on the login screen
  with nothing in any log to explain why;
- it is written while the client is **closed**, or the store appends on top of a
  live handle.

Verified end to end against a real client: switching to an account that had
never been signed in on this desktop brought the client up **logged in to it**,
with `[GatewaySocket] [READY]` in the client's own renderer log. The same
startup with the bare (unquoted) value produced no gateway connection at all.
A backup of the whole store is taken before any write, into
`%APPDATA%\quest_sim\leveldb_backup\`.

**The token engine does not need any of this.** Only the client window needs a
saved desktop session. Quests run over the REST API from the token alone, so a
freshly pasted token starts earning progress immediately — even for an account
that has never been near this desktop.

The whole operation runs on a worker thread, so the window never freezes; the
button greys out and says *switching…* while it works and comes back whatever
happened. Closing the window mid-switch asks first, because stopping halfway
through a directory swap is how you end up with a client that has no profile.

Read `discord_switch.py` as a standalone tool too:

```bash
py -3 discord_switch.py                 # list installs, running state, saved profiles
py -3 discord_switch.py --token <token> # switch for real
```

## CLI

One engine, two task families:

| Task family | Endpoint | Rate |
|---|---|---|
| `PLAY_ON_DESKTOP`, `PLAY_ON_PLAYSTATION` | `POST /quests/<id>/heartbeat {"application_id", "terminal"}` every 20s | real time — the server credits elapsed time between beats |
| `WATCH_VIDEO`, `WATCH_VIDEO_ON_MOBILE` | `POST /quests/<id>/video-progress {"timestamp"}` | 7x, capped at `(now − enrolled_at) + 10s` |
| `PLAY_ACTIVITY` | `POST /quests/<id>/heartbeat {"stream_key"}` (separate subcommand) | real time |

### How the token engine works

For `PLAY_ON_DESKTOP` the client does **not** run a local game detector as the
source of truth — it POSTs `{"application_id": ..., "terminal": false}` to
`/quests/<id>/heartbeat` every 20s and the **server** credits playtime between
calls, returning the new `user_status.progress`. The final call sets
`terminal: true`. So there is nothing to fake; the token is enough.

Two things the heartbeat endpoint insists on:

- **`X-Super-Properties`** — a base64 client fingerprint. Without it the
  heartbeat returns `401 {"code": 40001}` even though the token is valid
  everywhere else. The tool builds a fresh one per request.
- **`application_id`** — taken from
  `task_config_v2.tasks.PLAY_ON_DESKTOP.applications[0].id`.

The server credits time linearly, so a 900s quest takes 900 real seconds. It is
not a speed hack; it is the same heartbeat a real client sends, minus the client.

`WATCH_VIDEO` is separate: `/video-progress` accepts a `timestamp` and caps it at
`(now − enrolled_at) + 10s`, so video runs ahead of real time (7x here) but cannot
teleport to the end. That cap is why a video quest that was just accepted still
takes a few real seconds.

## Detection reality — read before running

Discord ramped service-side enforcement through 2026 and has suspended quest
access (not always the whole account) for people caught automating completion.
There is no invisible method. What the field has learned:

- **A token with no matching client session is separable from a real client.**
  `heartbeat` and `video-progress` calls are the exact shape this enforcement
  looks for.
- **Don't stack everything at once.** Running every quest at once is a pattern,
  not a person.
- **Auto-accept is on, always.** `POST /quests/<id>/enroll {"location": 11}`
  is the same call the client's *Accept Quest* button makes (Quest Home on
  desktop) and normally carries no captcha — only *claiming* is captcha-gated,
  which is still left to you. A quest that trips the rate limiter waits out
  `retry_after` and retries instead of being dropped.
  A scan (and the two-second auto-refresh behind it) enrolls anything waiting,
  so the list is ready to run without a click.
- **Claim rewards by hand.** Claiming presents a captcha and automating it is
  what turns a soft flag into a hard one.

Assume any account you run this on can lose quest access. Use an account you are
willing to lose.

## Requirements

- Python 3.10+ (`py -3` on Windows) to run from source
- The exe needs nothing installed, but needs the Edge **WebView2 runtime**
- From source: `py -3 -m pip install -r requirements-build.txt` (pywebview,
  Pillow, pystray). The engine is unaffected — `py -3 quest_sim.py list` still
  runs on the stdlib alone.

## Usage

```bash
# list active uncompleted quests (needs a token)
py -3 quest_sim.py list

# token-only: complete every quest by API, no process, no game
py -3 quest_sim.py token
py -3 quest_sim.py token --filter Typhoeus      # one quest by name

# activity quests need a voice-channel stream key
py -3 quest_sim.py activity --stream-key call:123456789012345678:1
```

Token goes in `--token` or `$DISCORD_TOKEN`; with neither, the tool auto-scans
the local Discord client. It is a full account credential — it can do anything
you can do. Keep it out of shell history and out of this repo.

## Files

- `dist/AutoDiscordQuest.exe` — the standalone build (~20 MB, no install)
- `quest_sim_app.py` — entry point: app / CLI / `--selftest` dispatch
- `quest_web.py` — the UI host: pywebview bridge, tray, Win32 window drag, and `--selftest`
- `ui/` — `index.html`, `app.css`, `app.js` — the interface itself
- `ui/music/` — drop audio files here and the Actions card plays them (name,
  play/pause, seek bar with time, volume). Bundled into the exe as `ui/music`.
- `discord_switch.py` — switches the installed Discord client's login session (per-account profile swap, plus the leveldb session write)
- `leveldb_write.py` — appends to a Chromium Local Storage leveldb with no native library
- `token_scan.py` — Discord token discovery: leveldb walk, DPAPI decrypt, `/users/@me` check
- `quest_sim.py` — CLI and the token engine
- `account_store.py` — the saved-token store
- `quest_sim.spec` — PyInstaller build definition
- `build_exe.bat` — one-click rebuild
- `requirements-build.txt` — runtime + build dependencies
- `start.bat` — double-click launcher for running from source

## Where the token comes from

Discord uses **Chromium OSCrypt**, not plain DPAPI. Two layers:

```
key     %APPDATA%\discord\Local State
        os_crypt.encrypted_key = base64( "DPAPI" + CryptProtectData(aes_key) )
        strip the 5-byte "DPAPI" tag, CryptUnprotectData -> 32-byte AES-256 key

value   %APPDATA%\discord\Local Storage\leveldb\*.ldb|*.log
        key   "_https://discord.com\x00\x01token"
        value "dQw4w9WgXcQ:" + base64( b"v10" + nonce(12) + ciphertext + tag(16) )
        AES-256-GCM under the key above -> plaintext token
```

The AES-GCM call goes through Windows CNG (`bcrypt.dll`) via ctypes, so there is
no third-party crypto dependency. Older clients stored a bare DPAPI blob after
the same prefix; that path is still tried, along with a regex pass for the
plaintext tokens ancient builds left in the leveldb. Every candidate is then
checked against `/users/@me` and only a live one is kept.

Note the leveldb files are held open by the running client. That is fine — the
scanner only reads, and leveldb appends rather than rewriting in place, so the
token is in `*.log` or an `*.ldb` regardless of whether Discord is running.

**A note on the quest schema.** `/quests/@me` moved from camelCase (`userStatus`,
`taskConfig`, `expiresAt`) to snake_case (`user_status`, `task_config`,
`expires_at`) without a version bump, and both shapes are still in circulation.
The parser reads either through a small `pick()` helper. This matters more than
it sounds: a camelCase-only parser does not error on the new payload, it just
silently matches nothing and reports zero quests.

**A note on the quest list.** `/quests/@me` returns a rotating set that varies
between calls, and video quests in particular come and go — a video quest may be
absent for a while and reappear. `list` shows whatever is live at that moment.
`/quests/<id>` also resolves quests that are not in the main list.

## Troubleshooting

**The quest list is empty** — read the log line. `available but not accepted`
means those quests are live but Discord would not enroll them (captcha demanded,
or enrollment blocked). Accept them in Discord's Quests tab, then Refresh.

**The app opens at Windows startup but does nothing** — the autostart entry
waits 20 seconds before opening the window so the shell, WebView2 and audio
are up first. If it still misbehaves, read `%APPDATA%\quest_sim\startup.log`:
every launch appends timestamped milestones, and a launch that never got wired
says exactly how far it got 45 seconds in.

**A new quest does not appear until you press Refresh** — it should, within ten
minutes. While a token is loaded and auto-accept is on, the tool re-polls
`/quests/@me` every ten minutes and enrolls anything new by itself; that poll
only writes to the console when the list actually changed. The poll steps aside
while a worker runs, because redrawing the list would discard live progress rows.
`quest access suspended until ...` means Discord has enforced against automation
on that account, and no tool will work until it lifts.

**A play quest sits near the end for a while** — expected. Playtime is credited
against real elapsed time, so the last minute of a 15-minute quest is still a
real minute. Keep the tool running; the final `terminal: true` heartbeat marks it
complete at the target.

**A video quest finishes almost instantly, or not at all** — the server caps the
accepted timestamp at `(now − enrolled_at) + 10s`. A quest accepted long ago
finishes the moment the loop starts; one accepted seconds ago is paced out.

**`Play` quests complete but the reward won't claim** — claim it in the Quests
tab by hand. That click is deliberately not automated.
